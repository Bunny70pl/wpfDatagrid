﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<string> Slowa {  get; set; }
        public List<Produkt> Produkty { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            Slowa = new List<string>();
            Produkty = new List<Produkt> { };
            Slowa.Add("gpra");
            Slowa.Add("dol");
            Slowa.Add("programista");
            Slowa.Add("informatyka");
            Slowa.Add("elektronika");
            Slowa.Add("matma");
            Slowa.Add("alkorytmy");
            DataContext = this;
            tak.ItemsSource = Slowa;
            nie.ItemsSource = Slowa;
            Produkty.Add(new Produkt("Komputer",2516,"Komputer biurowy",true,"Komputer"));
            Produkty.Add(new Produkt("Drukarka",767,"Drukara atrementowa",true,"Urzadzenia peryferyjne"));
            Produkty.Add(new Produkt("Mysz",180,"Myszka bezprzewodowa",true,"Akcesorium"));
            Produkty.Add(new Produkt("Mysz",180,"Myszka bezprzewodowa",true,"Akcesorium"));
            Produkty.Add(new Produkt("Mysz",180,"Myszka bezprzewodowa",true,"Akcesorium"));
            Produkty.Add(new Produkt("Mysz",180,"Myszka bezprzewodowa",true,"Akcesorium"));
            Produkty.Add(new Produkt("Mysz",180,"Myszka bezprzewodowa",true,"Akcesorium"));
            Produkty.Add(new Produkt("Mysz",180,"Myszka bezprzewodowa",true,"Akcesorium"));
            List<string> kategorieList = new List<string>();
            kategorieList.Add("Akcesorium");
            kategorieList.Add("Urzadzenia peryferyjne");
            kategorieList.Add("Komputer");
            kategoreDataGrid.ItemsSource = kategorieList;
        }
    }
}