﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp3
{
    public class Produkt
    {
        public string nazwa { get; set; }
        public float cena { get; set; }
        public string opisProduktu { get; set; }
        public bool dosteny {  get; set; }
        public string kategoria { get; set; }

        public Produkt(string nazwa, float cena, string opisProduktu, bool dosteny, string kategoria)
        {
            this.nazwa = nazwa;
            this.cena = cena;
            this.opisProduktu = opisProduktu;
            this.dosteny = dosteny;
            this.kategoria = kategoria;
        }
    }
}
